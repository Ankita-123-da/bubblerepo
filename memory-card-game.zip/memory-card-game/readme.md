# Memory Card Game Challenge

## How to Run:

1. Download the entire project folder.
2. Open `index.html` in your web browser.
3. Click on the cards to find matching pairs.
4. Enjoy the game and aim to finish in the shortest time!

## Folder Structure:
